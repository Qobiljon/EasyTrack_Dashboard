﻿namespace EasyTrack_Dashboard
{
    partial class CampaignCreatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.proceedButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rootTabControl = new System.Windows.Forms.TabControl();
            this.campaignDetailsTabPage = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.campaignDetailsRightPanel = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.addExperimenterButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.campaignDetailsLeftPanel = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.campaignManagersPanel = new System.Windows.Forms.Panel();
            this.currentProfile = new EasyTrack_Dashboard.ExperimenterProfile();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.rootTabControl.SuspendLayout();
            this.campaignDetailsTabPage.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.campaignDetailsRightPanel.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.campaignDetailsLeftPanel.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.campaignManagersPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.proceedButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 992);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1522, 45);
            this.panel1.TabIndex = 3;
            // 
            // proceedButton
            // 
            this.proceedButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.proceedButton.Dock = System.Windows.Forms.DockStyle.Right;
            this.proceedButton.Location = new System.Drawing.Point(1269, 0);
            this.proceedButton.Name = "proceedButton";
            this.proceedButton.Size = new System.Drawing.Size(253, 45);
            this.proceedButton.TabIndex = 0;
            this.proceedButton.Text = "PROCEED";
            this.proceedButton.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rootTabControl);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1522, 992);
            this.panel2.TabIndex = 4;
            // 
            // rootTabControl
            // 
            this.rootTabControl.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.rootTabControl.Controls.Add(this.campaignDetailsTabPage);
            this.rootTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rootTabControl.ItemSize = new System.Drawing.Size(0, 1);
            this.rootTabControl.Location = new System.Drawing.Point(0, 0);
            this.rootTabControl.Margin = new System.Windows.Forms.Padding(4);
            this.rootTabControl.Name = "rootTabControl";
            this.rootTabControl.SelectedIndex = 0;
            this.rootTabControl.Size = new System.Drawing.Size(1522, 992);
            this.rootTabControl.TabIndex = 3;
            // 
            // campaignDetailsTabPage
            // 
            this.campaignDetailsTabPage.Controls.Add(this.tableLayoutPanel1);
            this.campaignDetailsTabPage.Controls.Add(this.label1);
            this.campaignDetailsTabPage.Location = new System.Drawing.Point(4, 5);
            this.campaignDetailsTabPage.Margin = new System.Windows.Forms.Padding(4);
            this.campaignDetailsTabPage.Name = "campaignDetailsTabPage";
            this.campaignDetailsTabPage.Padding = new System.Windows.Forms.Padding(4);
            this.campaignDetailsTabPage.Size = new System.Drawing.Size(1514, 983);
            this.campaignDetailsTabPage.TabIndex = 0;
            this.campaignDetailsTabPage.Text = "Campaign Details TabPage";
            this.campaignDetailsTabPage.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.campaignDetailsRightPanel, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.campaignDetailsLeftPanel, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(4, 50);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1506, 929);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // campaignDetailsRightPanel
            // 
            this.campaignDetailsRightPanel.Controls.Add(this.campaignManagersPanel);
            this.campaignDetailsRightPanel.Controls.Add(this.tableLayoutPanel2);
            this.campaignDetailsRightPanel.Controls.Add(this.label6);
            this.campaignDetailsRightPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.campaignDetailsRightPanel.Enabled = false;
            this.campaignDetailsRightPanel.Location = new System.Drawing.Point(757, 4);
            this.campaignDetailsRightPanel.Margin = new System.Windows.Forms.Padding(4);
            this.campaignDetailsRightPanel.Name = "campaignDetailsRightPanel";
            this.campaignDetailsRightPanel.Padding = new System.Windows.Forms.Padding(17, 22, 17, 22);
            this.campaignDetailsRightPanel.Size = new System.Drawing.Size(745, 921);
            this.campaignDetailsRightPanel.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AutoSize = true;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.Controls.Add(this.textBox3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.addExperimenterButton, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(17, 864);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(711, 35);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox3.Location = new System.Drawing.Point(5, 5);
            this.textBox3.Margin = new System.Windows.Forms.Padding(5);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(558, 25);
            this.textBox3.TabIndex = 0;
            // 
            // addExperimenterButton
            // 
            this.addExperimenterButton.AutoSize = true;
            this.addExperimenterButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addExperimenterButton.Location = new System.Drawing.Point(571, 3);
            this.addExperimenterButton.Name = "addExperimenterButton";
            this.addExperimenterButton.Size = new System.Drawing.Size(137, 29);
            this.addExperimenterButton.TabIndex = 1;
            this.addExperimenterButton.Text = "ADD";
            this.addExperimenterButton.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Location = new System.Drawing.Point(17, 22);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.label6.Size = new System.Drawing.Size(132, 26);
            this.label6.TabIndex = 1;
            this.label6.Text = "Campaign Managers";
            // 
            // campaignDetailsLeftPanel
            // 
            this.campaignDetailsLeftPanel.Controls.Add(this.panel5);
            this.campaignDetailsLeftPanel.Controls.Add(this.panel4);
            this.campaignDetailsLeftPanel.Controls.Add(this.panel3);
            this.campaignDetailsLeftPanel.Controls.Add(this.panel6);
            this.campaignDetailsLeftPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.campaignDetailsLeftPanel.Location = new System.Drawing.Point(4, 4);
            this.campaignDetailsLeftPanel.Margin = new System.Windows.Forms.Padding(4);
            this.campaignDetailsLeftPanel.Name = "campaignDetailsLeftPanel";
            this.campaignDetailsLeftPanel.Size = new System.Drawing.Size(745, 921);
            this.campaignDetailsLeftPanel.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.textBox2);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 333);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(23, 30, 23, 30);
            this.panel5.Size = new System.Drawing.Size(745, 588);
            this.panel5.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.Location = new System.Drawing.Point(23, 56);
            this.textBox2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(699, 502);
            this.textBox2.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Location = new System.Drawing.Point(23, 30);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.label5.Size = new System.Drawing.Size(109, 26);
            this.label5.TabIndex = 2;
            this.label5.Text = "Campaign Name";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dateTimePicker2);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 222);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(17, 22, 17, 22);
            this.panel4.Size = new System.Drawing.Size(745, 111);
            this.panel4.TabIndex = 2;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker2.Location = new System.Drawing.Point(17, 48);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(711, 25);
            this.dateTimePicker2.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Location = new System.Drawing.Point(17, 22);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.label4.Size = new System.Drawing.Size(63, 26);
            this.label4.TabIndex = 2;
            this.label4.Text = "End Date";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dateTimePicker1);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 111);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(17, 22, 17, 22);
            this.panel3.Size = new System.Drawing.Size(745, 111);
            this.panel3.TabIndex = 1;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker1.Location = new System.Drawing.Point(17, 48);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(711, 25);
            this.dateTimePicker1.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Location = new System.Drawing.Point(17, 22);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.label3.Size = new System.Drawing.Size(68, 26);
            this.label3.TabIndex = 2;
            this.label3.Text = "Start date";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.textBox1);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(17, 22, 17, 22);
            this.panel6.Size = new System.Drawing.Size(745, 111);
            this.panel6.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(17, 48);
            this.textBox1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(711, 25);
            this.textBox1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Location = new System.Drawing.Point(17, 22);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.label2.Size = new System.Drawing.Size(109, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "Campaign Name";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.SteelBlue;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(4, 4);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1506, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "CAMPAIGN DETAILS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // campaignManagersPanel
            // 
            this.campaignManagersPanel.AutoScroll = true;
            this.campaignManagersPanel.Controls.Add(this.currentProfile);
            this.campaignManagersPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.campaignManagersPanel.Location = new System.Drawing.Point(17, 48);
            this.campaignManagersPanel.Name = "campaignManagersPanel";
            this.campaignManagersPanel.Size = new System.Drawing.Size(711, 816);
            this.campaignManagersPanel.TabIndex = 4;
            // 
            // currentProfile
            // 
            this.currentProfile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.currentProfile.Dock = System.Windows.Forms.DockStyle.Top;
            this.currentProfile.ExperimenterProfileType = "Experimenter";
            this.currentProfile.ExperimenterUsername = "Kevin";
            this.currentProfile.Location = new System.Drawing.Point(0, 0);
            this.currentProfile.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.currentProfile.MaximumSize = new System.Drawing.Size(2, 88);
            this.currentProfile.MinimumSize = new System.Drawing.Size(196, 90);
            this.currentProfile.Name = "currentProfile";
            this.currentProfile.Padding = new System.Windows.Forms.Padding(10);
            this.currentProfile.Size = new System.Drawing.Size(196, 90);
            this.currentProfile.TabIndex = 0;
            // 
            // CampaignCreatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1522, 1037);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Calibri", 11F);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(912, 731);
            this.Name = "CampaignCreatorForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "CampaignCreatorForm";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.rootTabControl.ResumeLayout(false);
            this.campaignDetailsTabPage.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.campaignDetailsRightPanel.ResumeLayout(false);
            this.campaignDetailsRightPanel.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.campaignDetailsLeftPanel.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.campaignManagersPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button proceedButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabControl rootTabControl;
        private System.Windows.Forms.TabPage campaignDetailsTabPage;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel campaignDetailsRightPanel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button addExperimenterButton;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel campaignDetailsLeftPanel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel campaignManagersPanel;
        private ExperimenterProfile currentProfile;
    }
}