﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Json;
using System.Net.Http;
using System.Threading;
using System.Windows.Forms;

namespace EasyTrack_Dashboard
{
    public partial class CampaignCreatorForm : Form
    {
        public CampaignCreatorForm()
        {
            InitializeComponent();

            loadCampaignManagersList();
            loadDataSources();
        }

        private void loadCampaignManagersList()
        {
            // Apply the current experimenter's details
            currentProfile.ExperimenterUsername = Properties.Settings.Default.Username;
            currentProfile.ExperimenterProfileType = Properties.Settings.Default.Type;
        }

        private void loadDataSources()
        {
            new Thread(async () =>
            {
                try
                {
                    HttpResponseMessage response = await Tools.post(Tools.API_GET_UNIQUE_DATA_SOURCES, new Dictionary<string, string>
                    {
                        { "username", Properties.Settings.Default.Username },
                        { "password", Properties.Settings.Default.Password },
                    });

                    if (response.IsSuccessStatusCode)
                    {
                        JsonObject resJson = (JsonObject)JsonValue.Parse(await response.Content.ReadAsStringAsync());
                        if (resJson.ContainsKey("result") && (ServerResult)int.Parse(resJson["result"].ToString()) == ServerResult.OK)
                        {
                            foreach (JsonObject dataSrc in resJson["sources"])
                                Console.WriteLine(dataSrc.ToString());
                        }
                        else
                            throw new Exception($"Bad result from server. Content: {resJson.ToString()}");
                    }
                    else
                        throw new Exception($"Bad http result, status code {response.StatusCode}");
                }
                catch (Exception ex)
                {
                    try
                    {
                        Tools.runOnUiThread(this, () => { MessageBox.Show(this, $"Error occurred while loading unique data sources.\nReason: {ex.Message}", "Failed to load the user list", MessageBoxButtons.OK, MessageBoxIcon.Error); });
                    }
                    catch
                    {

                    }
                }
            }).Start();
        }
    }
}
