﻿using System.Windows.Forms;

namespace EasyTrack_Dashboard
{
    public partial class CampaignElement : UserControl
    {
        public CampaignElement()
        {
            InitializeComponent();
        }
    }
}
